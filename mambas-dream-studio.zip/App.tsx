import React, { useState } from 'react';
import HomePage from './components/pages/HomePage';
import CatgirlGeneratorPage from './components/pages/CatgirlGeneratorPage';
import CatboyGeneratorPage from './components/pages/CatboyGeneratorPage';
import ImageRemixPage from './components/pages/ImageRemixPage';
import Header from './components/Header';

export type Page = 'home' | 'catgirl' | 'catboy' | 'remix';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'catgirl':
        return <CatgirlGeneratorPage onBack={() => navigateTo('home')} />;
      case 'catboy':
        return <CatboyGeneratorPage onBack={() => navigateTo('home')} />;
      case 'remix':
        return <ImageRemixPage onBack={() => navigateTo('home')} />;
      case 'home':
      default:
        return <HomePage onNavigate={navigateTo} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 p-4 sm:p-6 lg:p-8 flex flex-col">
      <div className="max-w-7xl mx-auto w-full flex-grow">
        <Header />
        <main className="mt-8">
          {renderPage()}
        </main>
      </div>
      <footer className="mt-12 text-center text-gray-500 text-sm pb-4">
        <p>&copy; {new Date().getFullYear()} <a href="https://mambas.in" className="hover:text-pink-400 transition-colors">Mambas.in</a>. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default App;